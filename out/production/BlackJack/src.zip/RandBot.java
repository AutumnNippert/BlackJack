import java.util.ArrayList;

public class RandBot implements Controller {
    public ArrayList<Card> hand;

    public RandBot() {
        this.hand = new ArrayList<>();
    }

    @Override
    public void addCard(Card c) {
        this.hand.add(c);
    }

    @Override
    public Card selectCard() {
        return null;
    }

    @Override
    public Card playCard() {
        return null;
    }

    @Override
    public String toString() {
        StringBuilder str = new StringBuilder("Hand: ");
        for (Card c : hand) {
            str.append(c).append(", ");
        }
        return str.toString();
    }
}
