import java.util.ArrayList;
import java.util.Arrays;

public class BlackJackGame {
    ArrayList<Controller> controllers;

    public BlackJackGame(Controller... controllers) {
        this.controllers = new ArrayList<>();
        this.controllers.addAll(Arrays.asList(controllers));
    }

    public void init() {
        System.out.println("Starting Game");
    }

}
