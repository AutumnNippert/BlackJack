import java.util.Random;

public class Dealer {

    /**
     * Deals a card to Controller c.
     * @param c controller
     */
    public static void deal(Controller c) {
        Random r = new Random();
        c.addCard(new Card(Card.Value.values()[r.nextInt(12)], Card.Suit.values()[r.nextInt(3)])); //Generating random card since no real deck is needed for blackjack
    }

}
