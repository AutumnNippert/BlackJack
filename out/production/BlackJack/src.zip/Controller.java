public interface Controller {
    void addCard(Card c);
    Card selectCard();
    Card playCard();
    String toString();
}
