import java.util.ArrayList;

public class Player implements Controller {
    public ArrayList<Card> hand;

    public Player() {
        this.hand = new ArrayList<>();
    }

    @Override
    public void addCard(Card c) {
        this.hand.add(c);
    }

    @Override
    public Card selectCard() {
        System.out.println();
    }

    @Override
    public Card playCard() {
        return null;
    }

    @Override
    public String toString() {
        StringBuilder str = new StringBuilder("Hand: ");
        for (Card c : hand) {
            str.append(c).append(", ");
        }
        return str.toString();
    }
}
